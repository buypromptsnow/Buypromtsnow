GINGERBREAD KNIGHT — GORILLA CHAMPION

Original Roblox-style model based on the supplied Gingerbread Knight concept.
Toasted cookie gorilla, pointed biscuit crest, ornate honey-gold armor and purple cloth wraps.

BLENDER
Open Gingerbread_Knight.blend in Blender 4.3 or newer. All geometry and materials are included.
Enable Gingerbread_Knight_Rig's eye icon in the Outliner, select it, and enter Pose Mode.
Root moves the entire model. Named R15-style body controls pose the segmented cookie body and armor.
The studio camera, lights and display plinth are in the optional STUDIO collection.
Front is -Y, up is +Z; one Blender unit represents one Roblox stud.

ROBLOX / FBX
The package includes a character-only FBX with its skeleton and base material colors.
The proportions are a custom gorilla knight, not a validated Roblox catalog avatar.
Roblox Studio import, Humanoid setup, animation retargeting and avatar compliance are not tested here.
Procedural baked pores and fine material texture remain native Blender shaders; FBX retains the modeled crumbs, armor, scrolls and base colors.

EDITING
Body, armor, embossed scrollwork, purple cloth and face are in separate CHARACTER collections.
Each mesh has rig_bone and category metadata and rigid named vertex weights.
Details are real geometry: raised cookie crumbs, gold curls, rivets, fingers, toes and ribbon tails.
No external textures, plugins or source models are required to open this file.
