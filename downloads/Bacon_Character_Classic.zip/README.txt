CLASSIC BACON CHARACTER

This revision uses archived native Roblox geometry and texture assets matching the supplied screenshots.
Pal Hair geometry and painted streaks, motorcycle shirt, dark green jeans, original Pal Face (86485810), and white skin.
The face is shaded directly on the native head mesh, using its original decal UV layout.
There are no generated hair strands, extruded lapels, redrawn faces or remodeled shoes in this revision.

OPEN & POSE
Open in Blender 4.3+. Enable Bacon_Rig's eye icon in the Outliner, select it, and enter Pose Mode.
Rotate Head, Arm.L/R and Leg.L/R; Root moves the entire avatar. Limbs are classic rigid R6 blocks.
Meshes have their original geometry/UVs and named rigid weights. All textures are packed.
Front is -Y, up is +Z; one unit equals one Roblox stud.
Hide the STUDIO collection to use the avatar without its presentation setup.

SOURCE ACCURACY
The source is a native Studio export of a standard bacon avatar, with the screenshot's Pal Face and white skin applied.
The supplied profile was user 5073176792. Its current outfit could not be independently queried because Roblox endpoints were unavailable.
This file is not asserted to be a verified export of that account or a pixel-identical copy of thumbnail lighting/poses.

ORIGINAL ASSET SOURCES
Roblox owns the original character assets. This is a conversion for the requested Blender workflow.
Native meshes, UVs and baked motorcycle shirt / pants / Pal Hair atlas:
https://github.com/evified/rooblox/tree/68c196260346882eef3d4ab4af93d5fd8a1c5554/source
Pal Face original texture, Roblox asset 86485810:
https://github.com/synpixel/roblox-classic-faces/blob/29101f2a77dc08507ec29f28780e244007536edf/classic-faces/86485810.png
