BACON CHARACTER

Open Bacon_Character.blend in Blender 4.3 or newer.

Contents
- Editable block-style character based on the supplied references.
- Separate orange/gold hair locks, black jacket, blue shirt, green pants and sneakers.
- Packed original smirking face texture; no external texture files are needed.
- Basic seven-bone rig for classic rigid-limb posing.
- Studio lights, portrait camera and display plinth.

Posing
Select Bacon_Rig in the Outliner and enable its eye icon. Enter Pose Mode.
Rotate Head, Arm.L, Arm.R, Leg.L and Leg.R. Root moves the entire character.
Limbs are classic rigid blocks; there are no bending elbows or knees.

Rendering
Press F12 to render the studio portrait.
Hide the STUDIO collection to use the character in a different scene.
Forward is -Y and up is +Z. Nominal character height is 6.5 Blender units.

The Blender file is self-contained. The build scripts and face.png are only
included for editing or regenerating the asset; they are not needed to open it.
